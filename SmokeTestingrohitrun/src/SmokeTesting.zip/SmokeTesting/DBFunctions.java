package SmokeTesting;

import java.awt.AWTException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBFunctions {

	public static void OpenSQLConnection() throws ClassNotFoundException, AWTException, InterruptedException {
		Connection Conn = null;
        //Robot rb = new Robot();
		//final Runtime rt = Runtime.getRuntime();
		
			 	/*Process p = rt.exec("cmd /C C:\\Users\\amolik.s\\Desktop\\ConnSQLNEC.bat");
			 	Thread.sleep(10000);
	            StringSelection pwd = new StringSelection("Kakinada123#");
	            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(pwd, null);
	            rb.keyPress(KeyEvent.VK_CONTROL);
	            rb.keyPress(KeyEvent.VK_V);
	            rb.keyRelease(KeyEvent.VK_V);
	            rb.keyRelease(KeyEvent.VK_CONTROL);
	           
	            //press enter
	            rb.keyPress(KeyEvent.VK_ENTER);
	            rb.keyRelease(KeyEvent.VK_ENTER);
			 	 */
		 
		try {
			
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Conn = DriverManager.getConnection("jdbc:sqlserver://10.4.2.26:1433;DatabaseName=ReservationSystemDev","sa","Sql2012");
			//Conn = DriverManager.getConnection("jdbc:sqlserver://LIFERAYSQLDEV;databaseName=LIFERAYSQLDEV;integratedSecurity=true;authenticationScheme=NativeAuthentication","NA-IDM\\217216x715257","Kakinada123#");
			//jdbc.default.driverClassName=com.microsoft.sqlserver.jdbc.SQLServerDriver;
			//		jdbc.default.url=jdbc:sqlserver://LIFERAYSQLDEV;databaseName=LIFERAYSQLDEV;integratedSecurity=true;authenticationScheme=NativeAuthentication;
			System.out.println("Connected to Database...");
			Statement st = Conn.createStatement();
			String sqlStr = "select * from Countries";
			//String sqlStr = "select * from NEC_Market";
			System.out.println("Query Executed : "+ sqlStr);
			ResultSet rs = st.executeQuery(sqlStr);
			if(!rs.wasNull()) {
				System.out.println("Results of the Query as Below : ");
				while (rs.next()) {
					System.out.println(rs.getString("CountryName"));
					//System.out.println(rs.getString("name"));
				}
			} else {
				System.out.println("The Query fetched zero records...");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Connection Failed...");
			e.printStackTrace();
		}
		
		
		//return Conn;
	}
	
	public static Connection OpenMSSQLConnection(String sDBConnectionString, String sSQLUser, String sSQLPassword) throws ClassNotFoundException, AWTException, InterruptedException {
		Connection Conn = null;
        try {
        	DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
        	 
            Conn = DriverManager.getConnection(sDBConnectionString, sSQLUser, sSQLPassword);
            if (Conn != null) {
            	System.out.println("Connected to the database...");
            	
                DatabaseMetaData dm = (DatabaseMetaData) Conn.getMetaData();
            }
 
        } catch (SQLException ex) {
        	System.out.println("Failed to connect to database");
            ex.printStackTrace();
        }
		return Conn;
	}

	public static void ExecuteQuery(Connection Conn,String sSQLQueryString,String sReturnField) {
		//String sReturnValue=null;
		Statement st;
		try {
			st = Conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
					  ResultSet.CONCUR_READ_ONLY);
			ResultSet rs;
			rs = st.executeQuery(sSQLQueryString);
			System.out.println("Fired Query : " + sSQLQueryString);
			if(!rs.wasNull()) {
				System.out.println("Results of the Query as Below : ");
				while (rs.next()) {
					System.out.println(rs.getString(sReturnField));
					System.out.println(rs.getRow());
				}
			} else {
				System.out.println("The Query fetched zero records...");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Query which returns the count (single field) fetched through the query
	public static int ExecuteQueryCount(Connection Conn,String sSQLQueryString,String sReturnField) {
		Statement st;
		int iReturnValue = 0;
		try {
			st = Conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
					  ResultSet.CONCUR_READ_ONLY);
			ResultSet rs;
			rs = st.executeQuery(sSQLQueryString);
			System.out.println("Fired Query : " + sSQLQueryString);
			if (rs == null) {
				System.out.println("The Query fetched zero records...");
				return 0;
			}
			rs.last();
			if(rs.getRow() > 1 ) {
				System.out.println("The Query fetched more than one record(s)...");
				return 0;
			}
			System.out.println("Results of the Query as Below : ");
			rs.beforeFirst();
			while (rs.next()) {
				System.out.println(rs.getString(sReturnField));
				iReturnValue = rs.getInt(sReturnField);
			}
			return iReturnValue;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return iReturnValue;
		}
	}

	// Query which returns the number of rows fetched through the query
	public static int ExecuteQueryRows(Connection Conn,String sSQLQueryString) {
		Statement st;
		try {
			st = Conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
					  ResultSet.CONCUR_READ_ONLY);
			ResultSet rs;
			rs = st.executeQuery(sSQLQueryString);
			System.out.println("Fired Query : " + sSQLQueryString);
			if (rs == null) {
				System.out.println("The Query fetched zero records...");
				return 0;
			}
			rs.last();
			System.out.println("Count : " + rs.getRow());
			return rs.getRow();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
}
