package SmokeTesting;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.Augmenter;

import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class UtilityFunctions {

	static ATUTestRecorder recorder;
	
    public static String captureScreen(WebDriver Driver, String sFilepath) {
        try {
            WebDriver augmentedDriver = new Augmenter().augment(Driver);
            File source = ((TakesScreenshot)augmentedDriver).getScreenshotAs(OutputType.FILE);
            sFilepath = sFilepath + source.getName();
            FileUtils.copyFile(source, new File(sFilepath)); 
        }
        catch(IOException e) {
            sFilepath = "Failed to capture screenshot: " + e.getMessage();
        }
        return sFilepath;
    }    
    
	public static void checkAlert(WebDriver driver) {
	    try {
	        //WebDriverWait wait = new WebDriverWait(driver, 2);
	       // wait.until(ExpectedConditions.alertIsPresent());
	        Alert alert = driver.switchTo().alert();
	        alert.accept();
	    } catch (Exception e) {
	        //exception handling
	    	System.out.println("No Alerts were found.");
	    }
	}	

	public static void checkAlertToCancel(WebDriver driver) {
	    try {
	        //WebDriverWait wait = new WebDriverWait(driver, 2);
	       // wait.until(ExpectedConditions.alertIsPresent());
	        Alert alert = driver.switchTo().alert();
	        alert.dismiss();
	    } catch (Exception e) {
	        //exception handling
	    	System.out.println("No Alerts were found.");
	    }
	}

	public static WebDriver getHandleToWindow(WebDriver driver, String title){

        WebDriver popup = null;
        //Set<String> windowIterator = WebDriverInitialize.getDriver().getWindowHandles();
        Set<String> windowIterator = driver.getWindowHandles();
        System.err.println("No of windows :  " + windowIterator.size());
        for (String s : windowIterator) {
        	String windowHandle = s; 
        	//popup = WebDriverInitialize.getDriver().switchTo().window(windowHandle);
        	popup = driver.switchTo().window(windowHandle);
        	System.out.println("Window Title : " + popup.getTitle());
        	System.out.println("Window Url : " + popup.getCurrentUrl());
        	if (popup.getTitle().equals(title) ){
        		System.out.println("Selected Window Title : " + popup.getTitle());
        		return popup;
        	}
        }
        System.out.println("Window Title :" + popup.getTitle());
        System.out.println();
        return popup;
    }	
	
    public static void WindowsAuthenticationlogin(String sUserName,String sPassword) throws Exception {

        try {
            //wait - increase this wait period if required
            Thread.sleep(5000);
           
            //create robot for keyboard operations
            Robot rb = new Robot();

            //Enter user name by CTRL-V
            StringSelection username = new StringSelection(sUserName);
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(username, null);            
            rb.keyPress(KeyEvent.VK_CONTROL);
            rb.keyPress(KeyEvent.VK_V);
            rb.keyRelease(KeyEvent.VK_V);
            rb.keyRelease(KeyEvent.VK_CONTROL);

            //tab to password entry field
            rb.keyPress(KeyEvent.VK_TAB);
            rb.keyRelease(KeyEvent.VK_TAB);
            Thread.sleep(2000);

            //Enter password by CTRL-V
            StringSelection pwd = new StringSelection(sPassword);
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(pwd, null);
            rb.keyPress(KeyEvent.VK_CONTROL);
            rb.keyPress(KeyEvent.VK_V);
            rb.keyRelease(KeyEvent.VK_V);
            rb.keyRelease(KeyEvent.VK_CONTROL);
           
            //press enter
            rb.keyPress(KeyEvent.VK_ENTER);
            rb.keyRelease(KeyEvent.VK_ENTER);
           
            //wait
            Thread.sleep(5000);
        } catch (Exception ex) {
            System.out.println("Error in Login Thread: " + ex.getMessage());
        }
    }

    public static void EnterStringOnFocus(String sText) {
        try {
            //wait - increase this wait period if required
            Thread.sleep(5000);
           
            //create robot for keyboard operations
            Robot rb = new Robot();

            //Enter user name by CTRL-V
            StringSelection sInputText = new StringSelection(sText);
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(sInputText, null);            
            rb.keyPress(KeyEvent.VK_CONTROL);
            rb.keyPress(KeyEvent.VK_V);
            rb.keyRelease(KeyEvent.VK_V);
            rb.keyRelease(KeyEvent.VK_CONTROL);
            //wait
            Thread.sleep(5000);
        } catch (Exception ex) {
            System.out.println("Error in Focus Thread: " + ex.getMessage());
        }
    }

    public static String readField(WebElement dropdown, String sSearchText) {
    	List<WebElement> options = dropdown.findElements(By.tagName("option"));
    	for (WebElement option : options) {
    	   if (option.getText().equals(sSearchText)) {
    		   option.click();
    	       return option.getText();
    	   }
    	}
    	return null;  
    }

    public static String[] SplitValuesIntoArray(String sStringToSplit, String sStringDelimeter) {
		String sTheString = sStringToSplit ;
		//String aTheArray[] = new String[sTheString.length()] ;
		int iNoOfDollars = 0;
		// Finding the number of delimited String available in String  
		for (int i=0;i <= sTheString.length()-1; i++) {
			String ss = sTheString.substring(i, i+1);
			if (ss.contains(sStringDelimeter)) {
				iNoOfDollars++;
			}
		}
		iNoOfDollars++; // increasing the $ count by 1
		String aTheArray[] = new String[iNoOfDollars] ;
		// Start Splitting the values
		for (int i = 0;i <= iNoOfDollars; i++) {
			int iFirstSplit = sTheString.indexOf(sStringDelimeter);
			if (iFirstSplit == -1) {
				aTheArray[i] = sTheString;
				break;
			} else {
				aTheArray[i] = sTheString.substring(0, iFirstSplit);
		        sTheString = sTheString.substring(iFirstSplit+1);
			}
		}
		return aTheArray;  
	}
    
    public static boolean VerifyTextOnPage(WebDriver driver,String sValueToSearch) {
    	if(driver.getPageSource().contains(sValueToSearch)) {
    		return true;
    	}
    	else {
    		return false;
    	}
    }
    
    public static String deleteAllNonDigit(String s) {
        String temp = s.replaceAll("\\D", "");
        return temp;
    }

	public static void SetupRecorderFilePath(String sFilePathForVideos, String sFilePrefix) throws ATUTestRecorderException {
		DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
		  Date date = new Date();
		  //Created object of ATUTestRecorder
		  //Provide path to store videos and file name format.
		  recorder = new ATUTestRecorder(sFilePathForVideos,sFilePrefix+dateFormat.format(date),false);
	}
	
	public static void StartVideoRecorder() throws ATUTestRecorderException {
		// Start Video Recording
		recorder.start();
	}
	
	public static void StopVideoRecorder() throws ATUTestRecorderException {
		// Stop Video Recording
		recorder.stop();
	}
    
}
