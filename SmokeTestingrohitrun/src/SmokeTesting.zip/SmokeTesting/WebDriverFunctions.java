package SmokeTesting;

import java.io.File;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class WebDriverFunctions {
	public static WebDriver OpenWebDriver(HSSFWorkbook DataBook, String ShDriver, String sStringToSearch) {
		WebDriver driver = null; int DrvRow = 0 ; File fileIE = null; 
		//ProfilesIni profile = new ProfilesIni();
		HSSFSheet DataSheet = null;
		DataSheet = DataBook.getSheet(ShDriver);
		HSSFRow row2 = DataSheet.getRow(0);
		String sDriverName;

		for(int row=0; row <=DataSheet.getLastRowNum();row++)
		{
			// Store the value of Column A for comparing
			HSSFRow row1 = DataSheet.getRow(row);
			row2 = DataSheet.getRow(row);
			String value = row1.getCell(0).toString();
			
            // If Column A value is equal to variable
	        if (value.equals(sStringToSearch)){
	             DrvRow = row;
	             break;
	        }
		}		
		HSSFCell cDriverStatus,cDriverPath,cDriverProperty = null;
		cDriverStatus = row2.getCell(0) ;
		cDriverPath = row2.getCell(1) ;
		cDriverProperty = row2.getCell(2) ;
		
		System.out.println(DrvRow);		
		System.out.println(cDriverStatus.getStringCellValue());
		
		if (DrvRow > 2) {
			fileIE = new File(cDriverPath.getStringCellValue().toString());
			System.setProperty(cDriverProperty.getStringCellValue().toString(), fileIE.getAbsolutePath());
		}
		switch (DrvRow) {
		case 2:
			sDriverName = "FireFox";
			//FirefoxProfile myprofile = profile.getProfile("AutomationTester");
			driver = new FirefoxDriver();
			break;
		case 3:
			sDriverName = "InternetExplorer";
			driver = new InternetExplorerDriver();
			break;
		case 4:
			sDriverName = "GoogleChrome";
			driver = new ChromeDriver();
			break;
		}
		return driver;
	}
}
