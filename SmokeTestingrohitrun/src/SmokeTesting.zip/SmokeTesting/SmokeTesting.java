package SmokeTesting;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.mail.MessagingException;
import jxl.read.biff.BiffException;
import org.apache.poi.hssf.usermodel.*;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import atu.testrecorder.exceptions.ATUTestRecorderException;
import SmokeTesting.Constants;

import java.sql.Connection;

public class SmokeTesting {
	public static String baseURL,sIsVideoOn,sRecorderFilePath,RecorderFilePrefix,sHTMLReportsPath, sHTMLReportsPrefix,currentDate,sRunDate, sReportPath, sTimeOuts,sEnvironmentName,sStyleSheetPath;
	public static String parentWindowHandle,sBrowserName,sControlToEnable,sAuthentication,sAuthenticateUser,sAuthenticatePassword,sScreenShotPath,sGetTextFromControl,sSplitDelimeter;
	public static String sDBConnectionString,sSQLUser,sSQLPassword, sSQLQueryString, sSQLResult, sConnectToDatabase, sIsEMailOn;
	public static String sDataSheet,sFunctionSheet, sUtilitiesSheet, sDriversSheet, sDatabaseSheet, sObjectRepositorySheet,sEnvironmentSetUpSheet,sEmailSetUpSheet,sDatabaseQueriesSheet;
	public static HSSFWorkbook wb, wbgen, wbwrite ; static HSSFSheet sh, shgen ;
	public static Connection ConnDB;
	public static int iTimeoutValue;
	public static BufferedWriter bw;
	public static File file;
	public static WebDriver driver;
	public static boolean bVideoStarted=false, bExceptionOccurred=false, bParentWindow=true, bCompareValues=false;
	public static void main(String args[]) throws Exception 
	{
		try 
		{
			SmokeTesting.InitializeForTesting();
			
			SmokeTesting.ProceedWithTesting();
			
			SmokeTesting.CloseAfterTesting();

		} 
		catch (FileNotFoundException e) 
		{
				bExceptionOccurred = true;
				e.printStackTrace();
		} 
		catch (MessagingException e) 
		{
				bExceptionOccurred = true;
				e.printStackTrace();
		} 
		catch (InterruptedException e) 
		{
				bExceptionOccurred = true;
				e.printStackTrace();
		} 
		catch (NoSuchElementException e) 
		{
				bExceptionOccurred = true;
				e.printStackTrace();
		}
		if(bExceptionOccurred) 
		{
				if( bVideoStarted) 
				{
					bVideoStarted = false;
				}
				driver.quit();
		}
	}

	@BeforeTest
	public static void InitializeForTesting() throws BiffException, ATUTestRecorderException, IOException {
		// Worksheet having all the generic parameters
		wbgen = ExcelFunctions.OpenExcelWorkBook(Constants.FILE_NAME);
		Constants.FILE_NAME = ExcelFunctions.FindValueInExcelSheet(wbgen, Constants.APPLICATION_SHEET, 0, Constants.GET_THIS_ROW, 2); // Path for application datasheet
		sDataSheet = ExcelFunctions.FindValueInExcelSheet(wbgen, Constants.APPLICATION_SHEET, 0, Constants.GET_THIS_ROW, 1); // Data to be used for this application
		wbwrite = ExcelFunctions.OpenExcelWorkBook(Constants.FILE_NAME); // Workbook to write data
		sFunctionSheet = ExcelFunctions.FindValueInExcelSheet(wbgen, Constants.APPLICATION_SHEET, 0, Constants.GET_THIS_ROW, 11); // get the sheet name of all the functional data setups 
		sUtilitiesSheet = ExcelFunctions.FindValueInExcelSheet(wbgen, sFunctionSheet, 0, Constants.GET_FUNCTION, 1); // get the sheet name of Utilities
		sDriversSheet = ExcelFunctions.FindValueInExcelSheet(wbgen, sFunctionSheet, 0, Constants.GET_FUNCTION, 2); // get the sheet name of Driver setup
		sDatabaseSheet = ExcelFunctions.FindValueInExcelSheet(wbgen, sFunctionSheet, 0, Constants.GET_FUNCTION, 3);  // get the sheet name of Database setup
		sObjectRepositorySheet = ExcelFunctions.FindValueInExcelSheet(wbgen, sFunctionSheet, 0, Constants.GET_FUNCTION, 4); // get the sheet name of Object Repository
		sEnvironmentSetUpSheet = ExcelFunctions.FindValueInExcelSheet(wbgen, sFunctionSheet, 0, Constants.GET_FUNCTION, 5); // get the sheet name of Environment Setup
		sEmailSetUpSheet = ExcelFunctions.FindValueInExcelSheet(wbgen, sFunctionSheet, 0, Constants.GET_FUNCTION, 6); // Get the sheet name of EMail setup
		sDatabaseQueriesSheet = ExcelFunctions.FindValueInExcelSheet(wbgen, sFunctionSheet, 0, Constants.GET_FUNCTION, 7);	// Get the sheet name of Database Queries
		sBrowserName = ExcelFunctions.FindValueInExcelSheet(wbgen, sDriversSheet, 0, Constants.GET_THIS_ROW, 5 ); // Browser Name (FireFox,IE,Chrome,etc)
		System.out.println("Opening Browser: "+sBrowserName);
		driver = WebDriverFunctions.OpenWebDriver(wbgen, sDriversSheet, Constants.GET_THIS_ROW); // Browser driver to be used (IE, Chrome). Default is Firefox
		bVideoStarted = false;
		bExceptionOccurred = false;
		sIsVideoOn = ExcelFunctions.FindValueInExcelSheet(wbgen, sUtilitiesSheet, 0, "VideoRecorder", 1 ); // Parameter to get the status of Video Recorder
		sHTMLReportsPath = ExcelFunctions.FindValueInExcelSheet(wbgen, Constants.APPLICATION_SHEET, 0, Constants.GET_THIS_ROW, 5 ); // HTML Report Path to be used
		sHTMLReportsPrefix = ExcelFunctions.FindValueInExcelSheet(wbgen, Constants.APPLICATION_SHEET, 0, Constants.GET_THIS_ROW, 6 ); // HTML Report Prefix to be used
		currentDate = new SimpleDateFormat(Constants.DATE_FORMAT_FOR_FILE).format(new Date());
		sRunDate = new SimpleDateFormat(Constants.DATE_FORMAT_FOR_REPORT).format(new Date());
		sReportPath = sHTMLReportsPath + sHTMLReportsPrefix + currentDate + ".html";
		sScreenShotPath = sHTMLReportsPath;
		file = new File(sReportPath);
		if (!file.exists()) {
			file.createNewFile();
		}
		bw = new BufferedWriter(new FileWriter(sReportPath));
		if (sIsVideoOn.matches("On")) {
			//GenericCode.SetupRecorderFilePath(ExcelFunctions.FindValueInExcelSheet(wbgen, sUtilitiesSheet, 0, "VideoRecorder", 3 ), ExcelFunctions.FindValueInExcelSheet(wbgen, sUtilitiesSheet, 0, "VideoRecorder", 4 ));
			//GenericCode.StartVideoRecorder();
			bVideoStarted = true;
		}
		sTimeOuts = ExcelFunctions.FindValueInExcelSheet(wbgen, sUtilitiesSheet, 0, "TimeoutValue", 2 ); // Timeout (wait) to be used between controls
		sSplitDelimeter = ExcelFunctions.FindValueInExcelSheet(wbgen, sUtilitiesSheet, 0, "SplitDelimeter", 3 ); // Delimeter to split values
		if (sTimeOuts.indexOf(".") > 0) {
			sTimeOuts = sTimeOuts.substring(0, sTimeOuts.indexOf(".")); 
		}
		iTimeoutValue = Integer.parseInt(sTimeOuts);
	}
	
	@Test
	public static void ProceedWithTesting() throws Exception {
		try {
			// Worksheet having all the application specific parameters
			wb = ExcelFunctions.OpenExcelWorkBook(Constants.FILE_NAME);
			sh = wb.getSheet(sDataSheet);
			int iRows = sh.getLastRowNum();
			//String sGetLink = null;
			String sIsLinkHasParameters = null;
			String LinkParametersCount = null;
			String sLinkParameter01, sLinkParameter02, sLinkParameter03, sLinkParameter04, sLinkParameter05 = null;
			sEnvironmentName = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 1 ); // environment name to be used
			sStyleSheetPath = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 7 ); // Stylesheet path to be used
			sConnectToDatabase = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 16 ); // Connect to database Yes / No 
			sDBConnectionString = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 17 ); // Connection string for the database 
			sSQLUser = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 18 ); // Database user
			sSQLPassword = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 19 ); // Database User password
			if(sConnectToDatabase.equals(Constants.CONDITION_YES)) {
				ConnDB = DBFunctions.OpenMSSQLConnection(sDBConnectionString, sSQLUser, sSQLPassword); // Connect to the configured database
			}
			sIsEMailOn = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 20 ); // Is Send Email flag is set
			System.out.println("Starting for Application: "+sDataSheet);
			sAuthentication = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 13 );
			if (sAuthentication.matches(Constants.CONDITION_YES)) {
				sAuthenticateUser = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 14 );
				sAuthenticatePassword = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 15 );
				baseURL = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 2 ); // environment to be used
				baseURL = baseURL + ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 3 );
			}
			else{
				baseURL = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 2 ); // environment to be used
				baseURL = baseURL + ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 3 );
			}
			sIsLinkHasParameters = "No";
			sIsLinkHasParameters = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 6 );
			if (sIsLinkHasParameters.matches(Constants.CONDITION_YES)) {
				LinkParametersCount = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 7 );
				sLinkParameter01 = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 8 );
				sLinkParameter02 = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 9 );
				sLinkParameter03 = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 10 );
				sLinkParameter04 = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 11);
				sLinkParameter05 = ExcelFunctions.FindValueInExcelSheet(wb, sEnvironmentSetUpSheet, 0, Constants.GET_THIS_ROW, 12 );
				switch (LinkParametersCount) {
				case "1": // Adding parameter01 to the URL
					baseURL = baseURL + sLinkParameter01;
					break;
				case "2": // Adding parameter02 to the URL
					baseURL = baseURL + sLinkParameter01 + sLinkParameter02;
					break;
				case "3": // Adding parameter03 to the URL
					baseURL = baseURL + sLinkParameter01 + sLinkParameter02 + sLinkParameter03;
					break;
				case "4": // Adding parameter04 to the URL
					baseURL = baseURL + sLinkParameter01 + sLinkParameter02 + sLinkParameter03 + sLinkParameter04;
					break;
				case "5": // Adding parameter05 to the URL
					baseURL = baseURL + sLinkParameter01 + sLinkParameter02 + sLinkParameter03 + sLinkParameter04 + sLinkParameter05;
					break;
				}
			}
			ReportFunctions.ReportHeader(bw, sStyleSheetPath, sDataSheet, sEnvironmentName, baseURL, sRunDate);
			for (int i = 1; i <= iRows;i++) { // For each test case in the control sheet
				HSSFRow row = sh.getRow(i);
				String sTestCaseName = row.getCell(0).getStringCellValue();
				String sFunction = row.getCell(1).toString();
				if (!sFunction.isEmpty()) {
					if (row.getCell(4).getStringCellValue().matches(Constants.CONDITION_YES)) { // Should execute the test case or not
						System.out.println(sTestCaseName);
						ReportFunctions.ReportTestCaseNameData(bw, sTestCaseName);
						int iStartColumn = (int) row.getCell(1).getNumericCellValue(); // Start getting data from this column
						int iEndColumn = (int) row.getCell(2).getNumericCellValue(); // End getting data from this column
						String sParameterSheet = row.getCell(5).getStringCellValue(); // Get Data from this sheet
						int iTestCaseSteps = 1;
						sGetTextFromControl = null;
						for (int ii = iStartColumn; ii <= iEndColumn; ii++) { // For the range of Start and End columns
							String sControlName = ExcelFunctions.FindValueInExcelSheet(wb, sParameterSheet, 0, "Action", ii); // Column Name = Control Name
							String sControlValue = ExcelFunctions.FindValueInExcelSheet(wb, sParameterSheet, 0, Constants.GET_THIS_ROW, ii); // Control Value = Data 
							if (!sControlValue.isEmpty()) { // If the data is not empty then proceed
								System.out.println("Control Name: " +sControlName);
								String sTestCaseSteps = ExcelFunctions.FindValueInExcelSheet(wb, sParameterSheet, 0, "TestSteps", ii); // Test Case Steps
								String sExpectedValue = ExcelFunctions.FindValueInExcelSheet(wb, sParameterSheet, 0, "Expected", ii); // Expected  
								String sKeyword = ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 1); // get the control type like (input, dropdown) etc
								String sLocatorType = ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 2); // get the control identification type like (id, xpath, class) etc
								//String sCheckExistence = FindValueInExcelSheet(wb, "ColumnMapping", 0, sControlName, 8); // whether need to check the existence of this object
								String sIdentification = null;
								sIdentification = ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 3); // get the control identification like the finding the element
								String sSequenceStr = null;
								sSequenceStr = ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 4); // get the sequence of the control identification to find the element
								String sEncrypt = ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 8); // check whether the data should be encrypted in the report
								String sEncryptChr = ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 9); // get the encrypt character
								driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
								switch (sKeyword) {
								case "BrowserReLaunch": // Closing the browser
									driver.manage().deleteAllCookies();
									driver.close();
									break;
								case "GetTextFrom":
								case "GetTextToUpdate":
									sGetTextFromControl = LocatorFunctions.ControlToGetTextFrom(driver,sLocatorType,sIdentification);
									if(sEncrypt.equals(Constants.CONDITION_YES)) {
										sExpectedValue = sExpectedValue + " = " + sEncryptChr + sGetTextFromControl;
									} else {
										sExpectedValue = sExpectedValue + " = " + sControlValue + sGetTextFromControl;
									}
									break;
								case "GetFromAttribute": // Get the text value from attributes
									sGetTextFromControl = LocatorFunctions.ControlToGetTextFromAttributes(driver,sLocatorType,sIdentification, sSequenceStr);
									if(sEncrypt.equals(Constants.CONDITION_YES)) {
										sExpectedValue = sExpectedValue + " = " + sEncryptChr + sGetTextFromControl;
									} else {
										sExpectedValue = sExpectedValue + " = " + sControlValue + sGetTextFromControl;
									}
									break;
								case "CompareValues":
									String sDBSheet01 = ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 5); // get the first sheet name to compare
									int iDBRow01 = Integer.parseInt(ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 6)); // get the first Row Number to compare
									int iDBColumn01 = Integer.parseInt(ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 7)); // get the first Column Number to compare
									HSSFSheet sFirstSheet = null;
									sFirstSheet = wb.getSheet(sDBSheet01);
									HSSFRow s1stRow = sFirstSheet.getRow(iDBRow01);
									String sFirstValue = s1stRow.getCell(iDBColumn01).getStringCellValue();
									String sDBSheet02 = ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 10); // get the second sheet name to compare
									int iDBRow02 = Integer.parseInt(ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 11)); // get the second Row Number to compare
									int iDBColumn02 = Integer.parseInt(ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 12)); // get the second Column Number to compare
									HSSFSheet sSecondSheet = null;
									sSecondSheet = wb.getSheet(sDBSheet02);
									HSSFRow s2ndRow = sSecondSheet.getRow(iDBRow02);
									String sSecondValue = s2ndRow.getCell(iDBColumn02).getStringCellValue();
									sExpectedValue = sExpectedValue + " = Value " + sFirstValue + " and Value " + sSecondValue;
									if(sFirstValue == sSecondValue) {
										bCompareValues = true;
									} else {
										bCompareValues = false;
									}
									break;
								case "WaitFor":
									sExpectedValue = sExpectedValue + " = " + sControlValue + " milliseconds";
									break;
								default:
									if(sEncrypt.equals(Constants.CONDITION_YES)) {
										sExpectedValue = sExpectedValue + " = " + sEncryptChr;
									} else {
										sExpectedValue = sExpectedValue + " = " + sControlValue;
									}
									break;
								}
								ReportFunctions.ReportTestCaseDetails(bw, iTestCaseSteps, sTestCaseSteps, sExpectedValue);
								switch (sKeyword) {
								case "BrowserReLaunch": // re-launching the browser
								case "Application": // Opens Application 
									if(sKeyword.equals("BrowserReLaunch")) {
										driver = WebDriverFunctions.OpenWebDriver(wbgen, sDriversSheet, Constants.GET_THIS_ROW); // Browser driver to be used (IE, Chrome). Default is Firefox
									}
									driver.get(baseURL);
									if (sAuthentication.matches(Constants.CONDITION_YES)) {
										if(sKeyword.equals("BrowserReLaunch")) {
											UtilityFunctions.WindowsAuthenticationlogin(sLocatorType,sIdentification);
										}else{
											UtilityFunctions.WindowsAuthenticationlogin(sAuthenticateUser,sAuthenticatePassword);
										}
									}
									driver.manage().window().maximize();
									ReportFunctions.ReportTestCaseResult(bw,Constants._PASS);
									break;
								case "GetEMailLink": // Gets which link to be searched in the emails
									String sEMailIMAP = ExcelFunctions.FindValueInExcelSheet(wb, sEmailSetUpSheet, 0, Constants._OUTLOOK, 3);
									String sEMailId = ExcelFunctions.FindValueInExcelSheet(wb, sEmailSetUpSheet, 0, Constants._OUTLOOK, 1);
									String sEMailPass = ExcelFunctions.FindValueInExcelSheet(wb, sEmailSetUpSheet, 0, Constants._OUTLOOK, 2);
									String sEmailSubject = ExcelFunctions.FindValueInExcelSheet(wb, sEmailSetUpSheet, 0, sIdentification, 9);
									String sText1ToSearch = ExcelFunctions.FindValueInExcelSheet(wb, sEmailSetUpSheet, 0, sIdentification, 11);
									String sText2ToSearch = ExcelFunctions.FindValueInExcelSheet(wb, sEmailSetUpSheet, 0, sIdentification, 12);
									
									String sGetLink = null;
									if (GetFromEmail.IsNewEmailFound(sEMailIMAP, sEMailId, sEMailPass)) {
										sGetLink = GetFromEmail.GetLinkFromMailBox(sEMailIMAP, sEMailId, sEMailPass, sEmailSubject, sText1ToSearch, sText2ToSearch);
										driver.get(sGetLink);
									} else {
										System.out.println(Constants.NO_EMAILS_FOUND);
									}
									break;
								case "Loop": // Gets which functions needs to be looped 
									break;
								case "Input": // Inputting data into text fields 
								case "ClearData": // Clearing data from a field 
								case "FileOpen": // populating data into Input fields like upload files and read only fields 
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									LocatorFunctions.ControlToUse(driver, sLocatorType,sIdentification,sControlValue,sKeyword);
									ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									break;
								case "DropDown": // Selecting options from drop down fields
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									LocatorFunctions.ControlDropdown(driver, sLocatorType,sIdentification,sControlValue);
									ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									break;
								case "Click": // clicking the appropriate buttons
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									LocatorFunctions.ControlToUse(driver, sLocatorType, sIdentification, true);
									ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									break;
								case "DoubleClick": // double clicking the appropriate buttons
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									LocatorFunctions.ControlToUse(driver, sLocatorType, sIdentification, false);
									ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									break;
								case "MultiSelect": // Selecting Multiple options from the list
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									String[] aValuesToSplit = UtilityFunctions.SplitValuesIntoArray(sControlValue, sSplitDelimeter);
									for (int pi = 0;pi <= aValuesToSplit.length-1; pi++) {
										String sValue = aValuesToSplit[pi];
										LocatorFunctions.ControlToUseMultiSelect(driver, sLocatorType, sIdentification,sValue);
									}
									ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									break;
								case "MultiSelectX": // Selecting Multiple options from the list with XPATH only
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									String[] xValuesToSplit = UtilityFunctions.SplitValuesIntoArray(sControlValue, sSplitDelimeter);
									for (int pi = 0;pi <= xValuesToSplit.length-1; pi++) {
										String sValue = xValuesToSplit[pi];
										new Select(driver.findElement(By.xpath(sIdentification))).selectByVisibleText(sValue);
									}
									ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									break;
								case "SequenceClick": // clicking the appropriate option with available text
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									sIdentification = sIdentification + sControlValue + sSequenceStr;
									LocatorFunctions.ControlToUseSequence(driver, sLocatorType, sIdentification);
									ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									break;
								case "KEYTAB": // Tab Key press Tab 
								case "KEYENTER": // Tab Key press Enter
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									LocatorFunctions.ControlKeyPress(driver, sLocatorType,sIdentification,sControlValue,sKeyword);
									ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									break;
								case "WaitFor": // Wait for seconds
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									Thread.sleep(Integer.parseInt(sControlValue));
									ReportFunctions.ReportTestCaseResult(bw, " ");
									break;
								case "DisplayValue": // Wait for seconds
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									ReportFunctions.ReportTestCaseResult(bw, " ");
									break;
								case "CtrlKeyDown": // Control Key
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									Actions actionDN = new Actions(driver);
									actionDN.keyDown(Keys.LEFT_CONTROL);
									ReportFunctions.ReportTestCaseResult(bw, " ");
									break;
								case "CtrlKeyUp": // Control Key
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									Actions actionUP = new Actions(driver);
									actionUP.keyDown(Keys.LEFT_CONTROL);
									ReportFunctions.ReportTestCaseResult(bw, " ");
									break;
								case "WaitForElement": // Wait for element
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									LocatorFunctions.ControlToWaitForElement(driver, sLocatorType, sIdentification);
									ReportFunctions.ReportTestCaseResult(bw, " ");
									break;
								case "AlertOk": // Clicking OK on alerts if exists
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									Thread.sleep(5000);
									UtilityFunctions.checkAlert(driver);
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									Thread.sleep(2000);
									break;
								case "AlertCancel": // Clicking CANCEL on alerts if exists
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									Thread.sleep(5000);
									UtilityFunctions.checkAlertToCancel(driver);
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									Thread.sleep(2000);
									break;
								case "VerifyTitle": // Verifying windows Title
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									String sTitle = driver.getTitle().trim();
									//if (driver.getTitle().equals(sExpectedValue.trim()) == false) {
									if (sTitle.equals(sControlValue.trim())) {
										System.out.println("Expected Text '" + sExpectedValue + "' Found...: ");
										ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									} else {
										String sActVerifyTitle = UtilityFunctions.captureScreen(driver,sScreenShotPath);
										System.out.println("Expected Text '" + sExpectedValue + "' Not Found...: ");
										System.out.println(sActVerifyTitle);
										ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
									}
									break;
								case "Verify": // Verifying a particular text value which is present
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if (LocatorFunctions.CheckTextPresent(driver, sLocatorType,sIdentification,sControlValue.trim()) == false) {
										String sActVerify = UtilityFunctions.captureScreen(driver,sScreenShotPath);
										System.out.println("Expected Text '" + sControlValue + "' Not Found...: ");
										System.out.println(sActVerify);
										ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
									} else {
										System.out.println("Expected Text '" + sControlValue + "' Found...: ");
										ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									}
									break;
								case "VerifyFail": // Verifying a particular text value which is not present
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if (LocatorFunctions.CheckTextPresent(driver, sLocatorType,sIdentification,sControlValue.trim()) == false) {
										String sActVerify = UtilityFunctions.captureScreen(driver,sScreenShotPath);
										System.out.println("Expected Text '" + sControlValue + "' Not Found...: ");
										System.out.println(sActVerify);
										ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									} else {
										System.out.println("Expected Text '" + sControlValue + "' Found...: ");
										ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
									}
									break;
								case "VerifyPartial": // Verifying a Partial value
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if (LocatorFunctions.CheckPartialTextPresent(driver, sLocatorType,sIdentification,sControlValue.trim()) == false) {
										String sActVerify = UtilityFunctions.captureScreen(driver,sScreenShotPath);
										System.out.println("Expected Text '" + sControlValue + "' Not Found...: ");
										System.out.println(sActVerify);
										ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
									} else {
										System.out.println("Expected Text '" + sControlValue + "' Found...: ");
										ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									}
									break;
								case "Assert": // Assert a value, if found stop testing
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if (LocatorFunctions.CheckTextPresent(driver, sLocatorType,sIdentification,sControlValue.trim()) == false) {
										String sActVerify = UtilityFunctions.captureScreen(driver,sScreenShotPath);
										System.out.println("Expected Text '" + sControlValue + "' Not Found...: ");
										System.out.println(sActVerify);
										ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									} else {
										System.out.println("Expected Text '" + sControlValue + "' Found...: ");
										ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
										SmokeTesting.CloseAfterTesting();
									}
									break;
								case "VerifyText": // Verify a text anywhere on a web page
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if (UtilityFunctions.VerifyTextOnPage(driver, sControlValue)) {
										System.out.println("Expected Text '" + sControlValue + "' Found...: ");
										ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									}else {
										System.out.println("Expected Text '" + sControlValue + "' Not Found...: ");
										ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
									};
									break;
								case "VerifyEnabled": // Verify that an element is enabled or not on a web page
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if (LocatorFunctions.ControlToVerifyIsEnable(driver, sLocatorType,sIdentification) == true) {
										System.out.println("Expected Element '" + sControlName + "' is Enabled...: ");
										ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									}else {
										System.out.println("Expected Element '" + sControlName + "' is Disabled...: ");
										ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
									}
									break;
								case "VerifyDisabled": // Verify that an element is disabled or not on a web page
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if (!LocatorFunctions.ControlToVerifyIsEnable(driver, sLocatorType,sIdentification) == true) {
										System.out.println("Expected Element '" + sControlName + "' is Disabled...: ");
										ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									}else {
										System.out.println("Expected Element '" + sControlName + "' is Enabled...: ");
										ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
									}
									break;
								case "AssertText": // Assert a text anywhere on a web page and stop testing if fails
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if (UtilityFunctions.VerifyTextOnPage(driver, sControlValue)) {
										System.out.println("Expected Text '" + sControlValue + "' Found...: ");
										ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
										SmokeTesting.CloseAfterTesting();
									}else {
										System.out.println("Expected Text '" + sControlValue + "' Not Found...: ");
										ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									};
									break;
								case "SwitchToWindow": // Switching to a window
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if( bParentWindow == true)  {
								        parentWindowHandle = driver.getWindowHandle(); // save the current window handle.
									    bParentWindow = false;
								    }
									driver = UtilityFunctions.getHandleToWindow(driver,sControlValue);
									ReportFunctions.ReportTestCaseResult(bw, " ");
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									break;
								case "SwitchToFrame": // Switching to a Frame
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if( bParentWindow == true)  {
								        parentWindowHandle = driver.getWindowHandle(); // save the current window handle.
									    bParentWindow = false;
								    }
									LocatorFunctions.ControlToSwitchFrame(driver,sLocatorType,sIdentification);
									ReportFunctions.ReportTestCaseResult(bw, " ");
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									break;
								case "SwitchToIFrame": // Switching to an iFrame
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if( bParentWindow == true)  {
								        parentWindowHandle = driver.getWindowHandle(); // save the current window handle.
									    bParentWindow = false;
								    }
									LocatorFunctions.ControlToSwitchFrame(driver,sLocatorType,sIdentification);
									ReportFunctions.ReportTestCaseResult(bw, " ");
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									break;
								case "SwitchToTAB": // Switching to a Tab
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if( bParentWindow == true)  {
								        parentWindowHandle = driver.getWindowHandle(); // save the current window handle.
									    bParentWindow = false;
								    }
									LocatorFunctions.ControlToSwitchTAB(driver,sLocatorType,sIdentification);
									ReportFunctions.ReportTestCaseResult(bw, " ");
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									break;
								case "SwitchBack": // Switching Back to Parent window
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									driver.switchTo().window(parentWindowHandle); // Switch to parent window
									ReportFunctions.ReportTestCaseResult(bw, " ");
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									break;
								case "CloseWindow": // Closing a window
									if( bParentWindow == true)  {
								        parentWindowHandle = driver.getWindowHandle(); // save the current window handle.
									    bParentWindow = false;
								    }
								    driver.close();
								    driver = UtilityFunctions.getHandleToWindow(driver,sControlValue);
								    ReportFunctions.ReportTestCaseResult(bw, " ");
								    driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
								    break;
								case "ScrollDown": // Scroll Down the page to access the element
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									JavascriptExecutor js = (JavascriptExecutor) driver;
									js.executeScript("javascript:window.scrollBy(0,450)");
									ReportFunctions.ReportTestCaseResult(bw, " ");
									break;
								case "EnableElement": // Enabling an disabled element through JavaSript to fetch value
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									WebElement textbox = LocatorFunctions.ControlToEnableByScript(driver,sLocatorType,sIdentification);
									((JavascriptExecutor) driver).executeScript("arguments[0].enabled = true", textbox);
									sControlToEnable = (String) ((JavascriptExecutor) driver).executeScript("return arguments[0].value;", textbox);
									ReportFunctions.ReportTestCaseResult(bw, " ");
									break;
								case "GetFromAttribute": // Get the value from attributes
								case "GetTextFrom": // Getting text from a control
								case "GetTextToUpdate": // Getting text from a control to update excel
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if( sGetTextFromControl.isEmpty()) {
										ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
									}
									else {
										ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
										if (sKeyword.equals("GetTextToUpdate")|sKeyword.equals("GetFromAttribute")) {
											String sRemoveChar = ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 13);
											String sUpdateSheet = ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 5); // get the sheet name to update
											int iUpdateRow = Integer.parseInt(ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 6)); // get the Row Number to update
											int iUpdateColumn = Integer.parseInt(ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 7)); // get the Column Number to update
											if(sRemoveChar.equals(Constants.CONDITION_YES)) {
												sGetTextFromControl = UtilityFunctions.deleteAllNonDigit(sGetTextFromControl);
											}
											ExcelFunctions.UpdateExcelFile(Constants.FILE_NAME, sUpdateSheet, sGetTextFromControl, iUpdateRow, iUpdateColumn);
											if( !ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 10).isEmpty()) {
												String sDBSheet02 = ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 10); // get the second sheet name to update
												int iDBRow02 = Integer.parseInt(ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 11)); // get the second Row Number to update
												int iDBColumn02 = Integer.parseInt(ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 12)); // get the second Column Number to update
												ExcelFunctions.UpdateExcelFile(Constants.FILE_NAME, sDBSheet02, sGetTextFromControl, iDBRow02, iDBColumn02);
											}
											try {
												wb = ExcelFunctions.OpenExcelWorkBook(Constants.FILE_NAME);
											} catch (BiffException e) {
												// TODO Auto-generated catch block
												e.printStackTrace();
											}
										}
									}
									break;
								case "InputOnFocus": // Input a text when a control gets focus
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									UtilityFunctions.EnterStringOnFocus(sControlValue);
									ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									break;
								case "UpdateExcel": // Update excel file
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									//EnterStringOnFocus(sControlValue);
									//UpdateExcelFile(Constants.sFileName, sParameterSheet, sGetTextFromControl, 6, 13);
									String sUpdateSheet = ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 5); // get the sheet name to update
									int iUpdateRow = Integer.parseInt(ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 6)); // get the Row Number to update
									int iUpdateColumn = Integer.parseInt(ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 7)); // get the Column Number to update
									ExcelFunctions.UpdateExcelFile(Constants.FILE_NAME, sUpdateSheet, sGetTextFromControl, iUpdateRow, iUpdateColumn);
									if( !ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 10).isEmpty()) {
										String sDBSheet02 = ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 10); // get the second sheet name to update
										int iDBRow02 = Integer.parseInt(ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 11)); // get the second Row Number to update
										int iDBColumn02 = Integer.parseInt(ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 12)); // get the second Column Number to update
										ExcelFunctions.UpdateExcelFile(Constants.FILE_NAME, sDBSheet02, sGetTextFromControl, iDBRow02, iDBColumn02);
									}
									try {
										wb = ExcelFunctions.OpenExcelWorkBook(Constants.FILE_NAME);
									} catch (BiffException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
									ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									break;
								case "DBUpdateExcel": // Update excel file from Database query
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									String sDBUpdateSheet = ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 5); // get the sheet name to update
									int iDBUpdateRow = Integer.parseInt(ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 6)); // get the Row Number to update
									int iDBUpdateColumn = Integer.parseInt(ExcelFunctions.FindValueInExcelSheet(wb, sObjectRepositorySheet, 0, sControlName, 7)); // get the Column Number to update
									int iDBCount = 0;
									if(sConnectToDatabase.equals(Constants.CONDITION_YES)) {
										String sSQLQueryString = ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 2);
										if(ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 4).equals(Constants.CONDITION_YES)) {
											sSQLQueryString = sSQLQueryString + ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 5);
										}
										if(!ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 6).isEmpty()) {
											sSQLQueryString = sSQLQueryString + ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 6);
										}										
										if(!ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 7).isEmpty()) {
											sSQLQueryString = sSQLQueryString + ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 7);
										}										
										if(!ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 8).isEmpty()) {
											sSQLQueryString = sSQLQueryString + ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 8);
										}										
										if(ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 1).equals(Constants.CONDITION_YES)) {
											iDBCount = DBFunctions.ExecuteQueryCount(ConnDB,sSQLQueryString,ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 3));
											Integer.toString(iDBCount);
										} else {
											System.out.println("Query "+ sControlValue +" is not configured to run...");
										}
									} else {
										System.out.println(Constants.DB_NOT_CONFIFURED_MSG);
									}
									ExcelFunctions.UpdateExcelFile(Constants.FILE_NAME, sDBUpdateSheet, Integer.toString(iDBCount), iDBUpdateRow, iDBUpdateColumn);
									try {
										wb = ExcelFunctions.OpenExcelWorkBook(Constants.FILE_NAME);
									} catch (BiffException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
									ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									break;
								case "SelectTableRow": // Select a row from table
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									
									//WebElement Wbtable = ControlToUseTable(driver, sIdentificationType, sIdentification);
									
									break;
								case "VerifyTableRows": // Count rows in a table
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									List<WebElement> TableRows = LocatorFunctions.ControlToUseTableRowColumn(driver, sLocatorType, sIdentification);
									System.out.println("Table rows :"+ TableRows.size());
									int iValuetoVerify = Integer.parseInt(sControlValue);
									int iTableRows = TableRows.size();
									if(iTableRows == iValuetoVerify ) {
										ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									} else {
										ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
									}
									break;
								case "HoverOn":
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									LocatorFunctions.ControlHover(driver, sLocatorType,sIdentification);
									ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									break;
								case "ExecuteDBQuery":
									//ExecuteQueryCount
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if(sConnectToDatabase.equals(Constants.CONDITION_YES)) {
										String sSQLQueryString = ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 2);
										if(ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 4).equals(Constants.CONDITION_YES)) {
											sSQLQueryString = sSQLQueryString + ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 5);
										}
										if(!ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 6).isEmpty()) {
											sSQLQueryString = sSQLQueryString + ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 6);
										}										
										if(ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 1).equals(Constants.CONDITION_YES)) {
											DBFunctions.ExecuteQuery(ConnDB,sSQLQueryString,ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 3));
										} else {
											System.out.println("Query "+ sControlValue +" is not configured to run...");
										}
									} else {
										System.out.println(Constants.DB_NOT_CONFIFURED_MSG);
									}
									break;
								case "CompareValues":
									// Compare 2 Values
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if(bCompareValues) {
										ReportFunctions.ReportTestCaseResult(bw, Constants._PASS);
									} else {
										ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
									}
									break;									
								case "CompareAppDB":
									//ExecuteQueryCount
									driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
									if(sConnectToDatabase.equals(Constants.CONDITION_YES)) {
										String sSQLQueryString = ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 2);
										if(ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 4).equals(Constants.CONDITION_YES)) {
											sSQLQueryString = sSQLQueryString + ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 5);
										}
										if(!ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 6).isEmpty()) {
											sSQLQueryString = sSQLQueryString + ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 6);
										}										
										if(ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 1).equals(Constants.CONDITION_YES)) {
											DBFunctions.ExecuteQuery(ConnDB,sSQLQueryString,ExcelFunctions.FindValueInExcelSheet(wb, sDatabaseQueriesSheet, 0, sControlValue, 3));
										} else {
											System.out.println("Query "+ sControlValue +" is not configured to run...");
										}
									} else {
										System.out.println(Constants.DB_NOT_CONFIFURED_MSG);
									}
									break;
								} // Case
								iTestCaseSteps ++;
							} // if
							//*********************************
						} // Second Loop
						driver.manage().timeouts().implicitlyWait(iTimeoutValue, TimeUnit.SECONDS);
						Thread.sleep(3000);
					} // Second If
				}	// First If
			} // First Loop
		} catch (FileNotFoundException e) {
			ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
			bExceptionOccurred = true;
			e.printStackTrace();
		} catch (MessagingException e) {
			ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
			bExceptionOccurred = true;
			e.printStackTrace();
		} catch (InterruptedException e) {
			ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
			bExceptionOccurred = true;
			e.printStackTrace();
		} catch (NoSuchElementException e) {
			ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
			e.printStackTrace();
		} catch (ElementNotVisibleException e) {
			ReportFunctions.ReportTestCaseResult(bw, Constants._FAIL);
			bExceptionOccurred = true;
			e.printStackTrace();
		}
		if(bExceptionOccurred) {
			driver.close();
		}
	}
	
	@AfterTest
	public static void CloseAfterTesting() throws Exception {
		try {
			ReportFunctions.ReportFooter(bw);
			driver.quit();
			try {
				if(sIsEMailOn.equals(Constants.CONDITION_YES)) {
					SendMail.execute(sEmailSetUpSheet, wb, sHTMLReportsPath,sHTMLReportsPrefix + currentDate + ".html",sSplitDelimeter);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if( bVideoStarted) {
				//GenericCode.StopVideoRecorder();
				bVideoStarted = false;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}