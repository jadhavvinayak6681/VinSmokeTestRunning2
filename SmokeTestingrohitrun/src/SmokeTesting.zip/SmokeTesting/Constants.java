package SmokeTesting;

public class Constants {
	
	public static String FILE_NAME = "D:\\Selenium\\Data\\RobustData.xls";
	public static String APPLICATION_SHEET = "Application";
	public static String _PASS = "Pass";
	public static String _FAIL = "Fail";
	public static String GET_THIS_ROW = "Start";
	public static String _OUTLOOK = "Outlook"; 
	public static String GET_FUNCTION = "Functions";
	public static String CONDITION_YES = "Yes";
	public static String DATE_FORMAT_FOR_FILE = "yyyyMMdd_HHmmss";
	public static String DATE_FORMAT_FOR_REPORT = "MM-dd-yyyy HH:mm:ss";
	public static String DB_NOT_CONFIFURED_MSG = "Database is not configured to connect...";
	public static String NO_EMAILS_FOUND = "No EMails found in configured inbox...";
}
